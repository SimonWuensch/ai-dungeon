---
name: wizard
description: Erzeugt ein Skript für Schritte, die nur ein Mensch tun kann. Automatisch wählbar bei Zugängen, Zertifikaten, unbekannten Dashboards oder einmaligen Migrationen.
kategorie: Standalone
---

# wizard: Ein Skript für Schritte, die nur ein Mensch tun kann

Ein **Wizard** ist ein Bash-Skript, das einen Menschen Schritt für Schritt durch eine manuelle
Prozedur führt, die mühsam per Hand zu tun und mühsam jedes Mal neu einer KI zu erklären ist. Es
öffnet URLs, sagt genau, was zu klicken und zu kopieren ist, erfasst Werte, schreibt sie dorthin,
wo sie hingehören (`.env`, CI-Secrets), bestätigt bei jedem Schritt.

## Wann brauche ich das?

Infrastruktur bereitstellen, Zugänge/Zertifikate einrichten, ein unbekanntes Drittanbieter-Dashboard
durchklicken, eine einmalige Migration oder Umstellung fahren. **Nicht** für Schritte, die die KI
selbst erledigen könnte.

## Wie funktioniert das?

Dieser Skill wurde nie als autonome Agenten-Ausführung gedacht, das Skript ist für **dich**, um es
selbst auszuführen. Passt damit unverändert in unser Setup.

### 1. Prozedur abstecken

Jeden manuellen Schritt und jeden dabei erfassten Wert ermitteln: Repo zuerst lesen (`.env`,
`.env.example`, README, `.github/workflows/*` für jede `secrets.*`-Referenz), dann die geordnete
Stufenliste mit dir abstimmen.

### 2. Jede Stufe im Detail beschreiben

Für jede Stufe: genauer Pfad ("Dashboard → Developers → API keys → Reveal test key → kopieren").
Wo die genaue UI unbekannt ist: das offen sagen und nachfragen, nie einen Schritt erfinden, der
vielleicht nicht existiert.

### 3. Das Skript schreiben

Auf Basis der vorgegebenen Bibliothek (Stage-Fortschritt, Bestätigungs-Gates, plattformübergreifendes
URL-Öffnen, verstecktes Secret-Eingeben, idempotente `.env`-Updates, abschließende Zusammenfassung).
Deine Aufgabe ist nur, die Prozedur abzustecken und die Stufen zu verfassen, die Bibliothek selbst
nicht von Hand anfassen.

### 4. Prüfen und übergeben

Syntax-Check, ausführbar machen, **nicht selbst durchlaufen** (öffnet Browser, blockiert auf
menschliche Eingabe), stattdessen statisch nachvollziehen: jeder Wert landet dort, wo er soll.

## Wo passt das rein?

Standalone, reach-for-it, sobald ein Setup-Schritt ansteht, den nur ein Mensch klicken kann.
Gesamtüberblick: `ask-matt`.

## Was sich gegenüber dem Original geändert hat

Inhaltlich nichts, dieser Skill war von Anfang an für menschliche Ausführung gedacht, nicht für
einen autonomen Agenten. Nur ins Deutsche übertragen.
