---
name: prototype
kategorie: Standalone
aufruf: Kann automatisch gewählt werden
---

# prototype — Eine Design-Frage mit Wegwerfcode beantworten

Ein Prototyp ist **Wegwerfcode, der eine Frage beantwortet**. Die Frage entscheidet die Form.

## Wann brauche ich das?

Wenn unklar ist, ob ein Zustandsmodell/eine Logik sich richtig anfühlt, oder wie eine UI aussehen
soll — und das schwer auf Papier zu klären ist.

## Wie funktioniert das?

Zwei Zweige, je nach Frage:

- **"Fühlt sich diese Logik/dieses Zustandsmodell richtig an?"** → eine einzelne, teilbare
  HTML-Datei (Freispiel-Buttons plus geführte Walkthroughs), die den Zustandsautomaten durch schwer
  auf Papier durchdenkbare Fälle treibt.
- **"Wie soll das aussehen?"** → mehrere UI-Varianten auf einer Route, umschaltbar über einen
  URL-Parameter.

## Regeln, die für beide gelten

1. **Von Anfang an klar als Wegwerf markiert.** Liegt nah am Modul/der Seite, die es prototypt.
2. **Trivial zu starten.** Ein UI-Prototyp läuft über einen Task-Runner-Befehl deines Projekts
   (`npm run <name>` bei Angular, ein einfacher Maven-Aufruf bei Java); eine Logik-Demo ist eine
   einzelne HTML-Datei zum Doppelklicken.
3. **Keine Persistenz standardmäßig.**
4. **Kein Feinschliff.** Keine Tests, keine Fehlerbehandlung über das Nötigste hinaus.
5. **Zustand sichtbar machen** nach jeder Aktion.
6. **Nach der Klärung einfangen**: die validierte Entscheidung fließt in den echten Code, der
   Prototyp selbst wird als Referenz behalten (z.B. in einem eigenen Ordner mit klarem
   "PROTOTYP"-Namen im Repo) statt gelöscht zu werden.

Der Prototyp-Code selbst kommt als **Snippet**, das du speicherst und selbst ausführst — wie jeder
andere Code-Vorschlag auch.

## Was sich gegenüber dem Original geändert hat

- Keine autonome Dateierzeugung/-ausführung — du speicherst die eine Datei und startest sie selbst.
- Statt eines Commits auf einen eigenen `prototype/<name>`-Branch: ablegen, wo es bei euch für
  Referenzcode üblich ist (z.B. ein `prototype/`-Unterordner im Feature-Branch).
