---
name: tdd
description: Test-Driven Development im Rot-Grün-Loop. Automatisch wählbar, wenn ein Feature oder Bugfix test-first entstehen soll.
kategorie: Hauptfluss
---

# tdd: Test-Driven Development

Der Rot-Grün-Loop. Diese Referenz sorgt dafür, dass dabei Tests entstehen, die sich lohnen:
was ein guter Test ist, wo Tests hingehören, welche Anti-Patterns zu vermeiden sind.

## Wann brauche ich das?

Wenn ein Feature oder ein Bugfix test-first entstehen soll.

## Was ein guter Test ist

Tests verifizieren Verhalten über öffentliche Schnittstellen, nicht Implementierungsdetails. Ein
guter Test liest sich wie eine Spezifikation und übersteht Refactorings, weil er sich nicht für
interne Struktur interessiert.

## Nähte: wo Tests hingehören

Eine **Naht** ist die öffentliche Grenze, an der getestet wird. **Nur an vorher vereinbarten Nähten
testen**: vor dem ersten Test die Nähte festlegen und mit dir abstimmen: "Was ist die öffentliche
Schnittstelle, und welche Nähte sollten wir testen?"

## Anti-Patterns

- **Implementierungsgekoppelt**: mockt interne Kollaborateure, testet private Methoden.
- **Tautologisch**: die Assertion berechnet den Erwartungswert genauso wie der Code selbst.
- **Horizontales Schneiden**: erst alle Tests, dann alle Implementierung. Stattdessen **vertikale
  Slices**: ein Test, eine Implementierung, wiederholen.

## Regeln des Loops

- **Rot vor Grün.** Erst den fehlschlagenden Test schreiben, dann nur so viel Code wie nötig.
- **Eine Naht, ein Test, eine minimale Implementierung pro Runde.**
- **Refactoring gehört nicht zum Loop**, das ist Aufgabe von `code-review`.

Testläufe (rot bestätigen, grün bestätigen) sind bei uns direkt möglich, sowohl bei Angular/npm-
als auch bei Java/Maven-Projekten, auf Zuruf einzeln angestoßen. Der Loop läuft also nicht
autonom durch, sondern Runde für Runde mit dir als Ausführendem dazwischen.

## Wo passt das rein?

Kettenschritt im Hauptfluss, von `implement` an vereinbarten Nähten angetrieben. Bei einer
unklaren Schnittstellenform hilft `codebase-design` als Vokabular. Gesamtüberblick: `ask-simon`.

## Was sich gegenüber dem Original geändert hat

Fast nichts inhaltlich. Der einzige Unterschied ist, dass der Testlauf zwischen den Runden
jeweils von dir angestoßen wird, statt dass die KI ihn selbst autonom auslöst.
