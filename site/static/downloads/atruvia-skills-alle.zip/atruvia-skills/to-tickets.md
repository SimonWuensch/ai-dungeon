---
name: to-tickets
kategorie: Hauptfluss
aufruf: Nur manuell (/to-tickets)
---

# to-tickets — In Tracer-Bullet-Tickets zerlegen

Zerlegt einen Plan, eine Spec oder ein Gespräch in **Tickets**: vertikale Slices, jedes mit seinen
**Blocking-Kanten** (welche Tickets vorher fertig sein müssen).

## Wann brauche ich das?

Nach `to-spec`, um die Spec in greifbare, einzeln umsetzbare Tickets zu zerlegen.

## Wie funktioniert das?

### 1. Kontext sammeln

Aus dem Gespräch heraus arbeiten, ggf. eine übergebene Spec/ein Ticket vollständig lesen.

### 2. Codebase erkunden (optional)

Ticket-Titel und -Beschreibungen im Domain-Vokabular. Nach Prefaktorisierung suchen: "Mach die
Änderung leicht, dann mach die leichte Änderung."

### 3. Vertikale Slices entwerfen

Jeder Slice schneidet einen schmalen, aber vollständigen Pfad durch alle Schichten (Schema, API,
UI, Tests) — demonstrierbar oder verifizierbar für sich allein, passt in ein einzelnes frisches
Kontextfenster.

**Ausnahme — breiter Umbau**: ein mechanischer Umbau mit großem Blast-Radius (Spalte umbenennen,
gemeinsam genutzten Typ umtypisieren) wird nicht in vertikale Slices gezwungen, sondern als
**Expand–Contract** sequenziert: erst die neue Form daneben einführen, dann Aufrufer batchweise
migrieren (grün bleibt CI dabei), zuletzt die alte Form löschen.

### 4. Mit dir abstimmen

Vorschlag als nummerierte Liste: Titel, Blockiert-durch, was das Ticket liefert. Fragen: Stimmt die
Granularität? Sind die Blocking-Kanten korrekt? Iterieren, bis du zustimmst.

### 5. Tickets manuell nach Jira übertragen

**Kein automatisches Anlegen** — du überträgst jeden Ticket-Text selbst in Jira und verknüpfst die
Blocking-Kanten dort manuell (Jira unterstützt "blocked by"-Links, nur eben nicht automatisiert
durch die KI).

```markdown
# <Titel>

**Was zu bauen ist:** das Ende-zu-Ende-Verhalten aus Nutzersicht, keine Schicht-für-Schicht-Liste.

**Blockiert durch:** die Nummern/Titel der Tickets, die dieses hier voraussetzen, oder "Keine
(kann sofort starten)".

- [ ] Akzeptanzkriterium 1
- [ ] Akzeptanzkriterium 2
```

## Was sich gegenüber dem Original geändert hat

- Kein automatisches Anlegen pro Ticket auf dem Tracker — Ticket-Texte inkl. Blocking-Hinweisen
  kommen zum manuellen Übertragen und Verknüpfen in Jira.
