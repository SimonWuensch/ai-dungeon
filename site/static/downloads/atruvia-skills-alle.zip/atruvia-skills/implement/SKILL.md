---
name: implement
description: Setzt die Arbeit um, die eine Spec oder ein Ticket beschreibt.
disable-model-invocation: true
kategorie: Hauptfluss
---

# implement: Ein Ticket umsetzen

Setzt die Arbeit um, die eine Spec oder ein Ticket beschreibt.

## Wann brauche ich das?

Sobald ein Ticket oder eine Spec feststeht und umgesetzt werden soll, egal ob als Teil des
mehrstufigen Hauptflusses (nach `to-tickets`) oder direkt im selben Kontextfenster bei kleineren
Änderungen.

## Wie funktioniert das?

Da Code nicht direkt geändert werden kann, läuft das als enger, iterativer Dialog statt als
autonomer Durchlauf:

1. Die KI schlägt den nächsten Schritt als **Snippet** vor, an der vereinbarten Naht, test-first via
   `/tdd` wo sinnvoll.
2. Du übernimmst es (Apply-Button oder manuell) und lässt Typecheck/Test laufen (einzeln
   angestoßen, bestätigt möglich für Angular/npm **und** Java/Maven-Projekte).
3. Du gibst das Ergebnis zurück: rot oder grün.
4. Nächstes Snippet, bis das Ticket fertig ist.

Am Ende: einmal die volle Test-Suite laufen lassen, dann `/code-review` für den fertigen Diff.

**Committen bleibt bei dir.** Im Original committet der Agent selbst, das setzt voraus, dass er
den Arbeitsstand direkt kontrolliert. Da hier jede Änderung erst durch dich läuft (Review + Apply),
bist du auch diejenige Person, die den fertigen Stand committet, nachdem du ihn geprüft hast.

## So wenig Snippets wie möglich

Jedes Snippet kostet dich einen Wechsel: lesen, Datei finden, einfügen, zurück in den Chat. Das
zählt doppelt, weil hier ohnehin schon kein Apply auf den ganzen Diff möglich ist. Zwei Regeln
dagegen:

- **Bündeln statt zersplittern.** Alles, was zu einem Schritt gehört und in dieselbe Datei geht,
  kommt in einem Snippet, nicht in drei kleinen. Eine neue Methode plus ihr Test plus eine
  Typ-Ergänzung in derselben Datei sind ein Snippet, kein Snippet pro Gedanke. Nur wirklich
  unabhängige Dateien (z.B. Komponente und Service) rechtfertigen ein eigenes Snippet.
- **Ein Snippet pro Datei pro Runde**, nicht pro Zeile. Wenn eine Datei in derselben Runde mehrfach
  betroffen wäre, wird daraus ein einziges, vollständiges Snippet für diese Datei, keine Kette aus
  Mini-Diffs, die du nacheinander einfügst.

## Dateiname und Pfad vor jedem Snippet

**Jedes** Code-Snippet trägt direkt davor die vollständige, relative Pfadangabe zur Datei, in die es
gehört, als eigene Zeile, z.B.:

```
src/app/components/basis-vorlage-auswahl-dialog/basis-vorlage-auswahl-dialog.component.ts
```

Gilt auch für eine **neue** Datei (die Pfadangabe zeigt dann, wo sie angelegt werden muss) und für
Java/Maven-Module genauso wie für Angular/npm-Projekte. Ohne diese Zeile muss du raten, wo ein
Snippet hingehört, das kostet Zeit und ist eine der häufigsten Fehlerquellen beim manuellen
Übertragen.

## Wo passt das rein?

Kettenschritt im Hauptfluss nach `to-tickets` (oder direkt nach `grill-with-docs` bei kleineren
Änderungen), treibt `tdd` und schließt mit `code-review` ab. Gesamtüberblick: `ask-simon`.

## Was sich gegenüber dem Original geändert hat

Aus "Agent baut autonom durch, committet am Ende selbst" wird "Snippet vorschlagen, du wendest
es an, Test/Typecheck auf Zuruf, nächstes Snippet, du committest". Test-getrieben bleibt es in
beiden Fällen. Neu hinzugekommen (im Original nicht nötig, weil der Agent dort direkt in den Dateien
arbeitet): möglichst wenige, gebündelte Snippets, und jedes davon mit vorangestelltem Dateipfad.
